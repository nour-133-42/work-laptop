#include "PhoneBook.hpp"
#include <iostream>
#include <string>

void PhoneBook::run()
{
	std::string s;
	std::cout << "Enter command (ADD, SEARCH, EXIT): ";
	std::getline(std::cin, s);
	if (s == "ADD")
		this->add();
}

void PhoneBook::add()
{
	contact_info();
}

void PhoneBook::contact_info()
{
	std::string first_name;
	std::string last_name;
	std::string nickname;
	std::string phone_number;
	std::string darkest_secret;
	std::cout << "Enter first name: ";
	std::getline(std::cin, first_name);
	std::cout << "Enter last name: ";
	std::getline(std::cin, last_name);
	std::cout << "Enter nickname: ";
	std::getline(std::cin, nickname);
	std::cout << "Enter phone number: ";
	std::getline(std::cin, phone_number);
	if (this->contact[this->count % 8].set_phone_number(phone_number) == 1)
	{
		std::cout << "Invalid phone number. Please enter a valid phone number." << std::endl;
		return ;
	}
	std::cout << "Enter darkest secret: ";
	std::getline(std::cin, darkest_secret);
	this->contact[this->count % 8].set_first_name(first_name);
	this->contact[this->count % 8].set_last_name(last_name);
	this->contact[this->count % 8].set_nickname(nickname);
	this->contact[this->count % 8].set_darkest_secret(darkest_secret);
	this->count++;
}